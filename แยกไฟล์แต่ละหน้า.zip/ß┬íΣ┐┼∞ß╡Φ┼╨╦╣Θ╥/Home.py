
import streamlit as st

st.set_page_config(page_title="Brush Dashboard", layout="wide")
st.title("📊 Welcome to Brush Dashboard")

st.markdown("เลือกหน้าจากเมนูด้านซ้ายเพื่อเริ่มต้นใช้งาน")

st.markdown("เลือกหน้าจากเมนูด้านซ้ายเพื่อเริ่มต้นใช้งาน")
